# Code du projet

[Angular CLI](https://github.com/angular/angular-cli) version 10.2.0.

## Server Angular

`http://localhost:4200/`

## Server Backend Node.JS / Express

Répertoire `express_server`
`http://localhost:8080/`

## Utilitaire generation component

`ng generate component component-name` to generate a new component. You can also use `ng generate directive|pipe|service|class|guard|interface|enum|module`.

## Tests unitaires

`ng test` via [Karma](https://karma-runner.github.io).

## Test l'application avec un webdriver

`ng e2e` via [Protractor](http://www.protractortest.org/).
