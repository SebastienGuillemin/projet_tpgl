import { Sonde } from './sonde.model';

describe('Sonde', () => {
  it('should create an instance', () => {
    expect(new Sonde()).toBeTruthy();
  });
});
