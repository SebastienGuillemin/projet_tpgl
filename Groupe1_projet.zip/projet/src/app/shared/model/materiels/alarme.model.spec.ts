import { Alarme } from './alarme.model';

describe('Alarme', () => {
  it('should create an instance', () => {
    expect(new Alarme()).toBeTruthy();
  });
});
