import { Ventillation } from './ventillation.model';

describe('Ventillation', () => {
  it('should create an instance', () => {
    expect(new Ventillation()).toBeTruthy();
  });
});
