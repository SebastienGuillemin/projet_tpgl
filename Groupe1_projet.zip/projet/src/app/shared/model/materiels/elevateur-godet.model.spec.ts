import { ElevateurGodet } from './elevateur-godet.model';

describe('ElevateurGodet', () => {
  it('should create an instance', () => {
    expect(new ElevateurGodet()).toBeTruthy();
  });
});
