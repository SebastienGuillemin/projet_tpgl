import { Fosse } from './fosse.model';

describe('Fosse', () => {
  it('should create an instance', () => {
    expect(new Fosse()).toBeTruthy();
  });
});
