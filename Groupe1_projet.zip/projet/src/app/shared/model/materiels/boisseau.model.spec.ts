import { Boisseau } from './boisseau.model';

describe('Boisseau', () => {
  it('should create an instance', () => {
    expect(new Boisseau()).toBeTruthy();
  });
});
