import { PontBascule } from './pont-bascule.model';

describe('PontBascule', () => {
  it('should create an instance', () => {
    expect(new PontBascule()).toBeTruthy();
  });
});
