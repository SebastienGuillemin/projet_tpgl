import { Silo } from './silo.model';

describe('Silo', () => {
  it('should create an instance', () => {
    expect(new Silo()).toBeTruthy();
  });
});
