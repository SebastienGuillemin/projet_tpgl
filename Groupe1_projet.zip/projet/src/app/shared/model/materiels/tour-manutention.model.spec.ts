import { TourManutention } from './tour-manutention.model';

describe('TourManutention', () => {
  it('should create an instance', () => {
    expect(new TourManutention()).toBeTruthy();
  });
});
