import { Cellule } from './cellule.model';

describe('Cellule', () => {
  it('should create an instance', () => {
    expect(new Cellule()).toBeTruthy();
  });
});
