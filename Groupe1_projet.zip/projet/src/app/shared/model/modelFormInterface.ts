//Décrit l'interface d'une classe model utilisée dans un formulaire (User ...).

export interface ModelFormInterface {
    getFormFields(): Array<string>;
}